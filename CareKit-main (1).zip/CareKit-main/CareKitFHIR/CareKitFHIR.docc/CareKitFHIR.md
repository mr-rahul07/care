# ``CareKitFHIR``

CareKitFHIR is an open source framework that contains tools for mapping FHIR resources to CareKitStore data types.  
